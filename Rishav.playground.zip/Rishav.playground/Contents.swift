import UIKit

//var roll = 12
//let name = "Rishav"
//print(name)
//print("My name is \(name)")

var myVariable = 42
myVariable = 50
let myConstant = 42

let implictInteger = 70
let implictDouble = 70.0
let explictDouble: Double = 70
let explictFloat: Float = 4

let label = "The Width is "
let width = 94
let widthLabel = label + String(width)

let apples = 3
let oranges = 5
let appleSummary = "I have \(apples) apples."
let fruitSummary = "I have \(apples + oranges) pieces of fruit."

let quotation = """
Even though there's whitespace to the left,
the actual lines aren't idented.
Expect for this line.
Double quotes (") can appear without being escaped.
I still have \(apples + oranges) pieces of fruit.
"""

var fruits = ["strawberries", "limes", "tangerines"]
fruits[1] = "grapes"

var occupations = [
    "Malcolm": "Captain",
    "Kaylee": "Mechanic",
]
occupations["Jayne"] = "Public Replations"
fruits.append("blueberries")
print(fruits)

fruits = []
occupations = [:]

let emtyArray: [String] = []
let emptyDictonary: [String: Float] = [:]
